# OCSPANEL V1

wget -O ocspanel.sh https://raw.githubusercontent.com/rasta-team/OCS/master/ocspanel.sh && chmod +x ocspanel.sh && ./ocspanel.sh
